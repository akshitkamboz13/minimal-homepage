import { initTheme } from './theme/theme.js';
import { initClock } from './clock/clock.js';
import { initSearch } from './search/core/index.js';
import { initVoiceSearch } from './search/voice/voice.js';
import { initVisualSearch } from './search/visual/visual.js';
import { initBookmarks } from './bookmarks/index.js';
import { initPanels } from './ui/index.js';
import { initNotes } from './notes/notes.js';
import { initLayoutManager } from './ui/panels/layout-manager.js';
import { initContextMenu } from './ui/panels/context-menu.js';

export function initApp() {
    initTheme();
    initClock();
    initSearch();
    initVoiceSearch();
    initVisualSearch();
    initBookmarks();
    initPanels();
    initNotes();
    initLayoutManager();
    initContextMenu();
}
